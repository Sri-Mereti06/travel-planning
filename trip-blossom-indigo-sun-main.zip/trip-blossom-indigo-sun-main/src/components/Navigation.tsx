
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { MapPin, Calendar, Hotel, BusIcon, ChefHat } from 'lucide-react';

const Navigation = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Home', icon: MapPin },
    { path: '/destinations', label: 'Destinations', icon: MapPin },
    { path: '/budget', label: 'Budget', icon: Calendar },
    { path: '/hotels', label: 'Hotels', icon: Hotel },
    { path: '/transport', label: 'Transport', icon: BusIcon },
    { path: '/restaurants', label: 'Restaurants', icon: ChefHat },
  ];

  return (
    <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-md z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="text-2xl font-bold bg-gradient-to-r from-travel-orange-500 to-travel-purple-500 bg-clip-text text-transparent">
            TravelPlan
          </Link>
          
          <div className="hidden md:flex space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-travel-orange-100 to-travel-purple-100 text-travel-purple-700'
                      : 'text-gray-600 hover:text-travel-orange-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button className="text-gray-600 hover:text-travel-orange-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
