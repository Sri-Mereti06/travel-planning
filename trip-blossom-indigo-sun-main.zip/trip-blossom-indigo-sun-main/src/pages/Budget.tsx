
import React, { useState } from 'react';
import { Calculator, PieChart, TrendingUp } from 'lucide-react';
import Navigation from '../components/Navigation';

const Budget = () => {
  const [budget, setBudget] = useState({
    accommodation: 8000,
    transport: 5000,
    food: 4000,
    activities: 3000,
    shopping: 2000,
    miscellaneous: 1000
  });

  const [duration, setDuration] = useState(5);
  const [travelers, setTravelers] = useState(2);

  const totalBudget = Object.values(budget).reduce((sum, value) => sum + value, 0);
  const perPersonBudget = totalBudget / travelers;
  const dailyBudget = totalBudget / duration;

  const updateBudget = (category, value) => {
    setBudget(prev => ({
      ...prev,
      [category]: parseInt(value) || 0
    }));
  };

  const budgetCategories = [
    { key: 'accommodation', label: 'Accommodation', color: 'bg-travel-orange-500', icon: '🏨' },
    { key: 'transport', label: 'Transport', color: 'bg-travel-purple-500', icon: '🚗' },
    { key: 'food', label: 'Food & Dining', color: 'bg-travel-orange-400', icon: '🍽️' },
    { key: 'activities', label: 'Activities', color: 'bg-travel-purple-400', icon: '🎯' },
    { key: 'shopping', label: 'Shopping', color: 'bg-travel-orange-300', icon: '🛍️' },
    { key: 'miscellaneous', label: 'Miscellaneous', color: 'bg-travel-purple-300', icon: '💰' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      <div className="pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Smart
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Budget Planner</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Plan your travel expenses in Indian Rupees and stay within your budget
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Trip Details */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Trip Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Duration (Days)</label>
                    <input
                      type="number"
                      value={duration}
                      onChange={(e) => setDuration(parseInt(e.target.value) || 1)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                      min="1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Number of Travelers</label>
                    <input
                      type="number"
                      value={travelers}
                      onChange={(e) => setTravelers(parseInt(e.target.value) || 1)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                      min="1"
                    />
                  </div>
                </div>
              </div>

              {/* Budget Categories */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Budget Breakdown</h2>
                <div className="space-y-6">
                  {budgetCategories.map((category) => (
                    <div key={category.key} className="flex items-center space-x-4">
                      <div className={`w-12 h-12 ${category.color} rounded-xl flex items-center justify-center text-white font-bold`}>
                        {category.icon}
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          {category.label}
                        </label>
                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-bold text-gray-600">₹</span>
                          <input
                            type="number"
                            value={budget[category.key]}
                            onChange={(e) => updateBudget(category.key, e.target.value)}
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                            min="0"
                          />
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-500">
                          {((budget[category.key] / totalBudget) * 100).toFixed(1)}%
                        </div>
                        <div className="text-sm text-gray-500">
                          ₹{(budget[category.key] / duration).toFixed(0)}/day
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Budget Summary */}
            <div className="space-y-6">
              {/* Total Budget Card */}
              <div className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 rounded-2xl shadow-lg p-6 text-white">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Total Budget</h3>
                  <Calculator size={24} />
                </div>
                <div className="text-3xl font-bold mb-2">₹{totalBudget.toLocaleString()}</div>
                <div className="text-sm opacity-90">For {duration} days, {travelers} travelers</div>
              </div>

              {/* Per Person Budget */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Per Person</h3>
                  <TrendingUp className="text-travel-orange-500" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-2">₹{perPersonBudget.toLocaleString()}</div>
                <div className="text-sm text-gray-600">₹{(perPersonBudget / duration).toFixed(0)} per day</div>
              </div>

              {/* Daily Budget */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Daily Budget</h3>
                  <PieChart className="text-travel-purple-500" size={24} />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-2">₹{dailyBudget.toLocaleString()}</div>
                <div className="text-sm text-gray-600">For all {travelers} travelers</div>
              </div>

              {/* Budget Tips */}
              <div className="bg-gradient-to-br from-travel-orange-100 to-travel-purple-100 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">💡 Budget Tips</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Book accommodation in advance for better rates</li>
                  <li>• Consider local transport over private taxis</li>
                  <li>• Try local street food for authentic experience</li>
                  <li>• Look for combo deals on activities</li>
                  <li>• Keep 10-15% buffer for unexpected expenses</li>
                </ul>
              </div>

              {/* Save Budget Button */}
              <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-4 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                Save Budget Plan
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Budget;
