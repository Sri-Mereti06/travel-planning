
import React, { useState } from 'react';
import { MapPin, Calendar, Star } from 'lucide-react';
import Navigation from '../components/Navigation';

const Destinations = () => {
  const [selectedDestination, setSelectedDestination] = useState(null);

  const destinations = [
    {
      id: 1,
      name: 'Goa',
      image: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=400&h=300&fit=crop',
      rating: 4.8,
      price: '₹15,000',
      duration: '4-5 days',
      highlights: ['Beaches', 'Nightlife', 'Portuguese Architecture'],
      description: 'Perfect blend of relaxation and adventure with stunning beaches and vibrant culture.'
    },
    {
      id: 2,
      name: 'Kerala',
      image: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=400&h=300&fit=crop',
      rating: 4.9,
      price: '₹20,000',
      duration: '6-7 days',
      highlights: ['Backwaters', 'Hill Stations', 'Ayurveda'],
      description: 'Gods own country with serene backwaters and lush green landscapes.'
    },
    {
      id: 3,
      name: 'Rajasthan',
      image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=400&h=300&fit=crop',
      rating: 4.7,
      price: '₹25,000',
      duration: '7-8 days',
      highlights: ['Palaces', 'Desert Safari', 'Culture'],
      description: 'Royal heritage with magnificent palaces and desert adventures.'
    },
    {
      id: 4,
      name: 'Himachal Pradesh',
      image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=400&h=300&fit=crop',
      rating: 4.6,
      price: '₹18,000',
      duration: '5-6 days',
      highlights: ['Mountains', 'Adventure Sports', 'Snow'],
      description: 'Mountain paradise perfect for adventure enthusiasts and nature lovers.'
    },
    {
      id: 5,
      name: 'Uttarakhand',
      image: 'https://images.unsplash.com/photo-1626619949846-d4ba6b6ced66?w=400&h=300&fit=crop',
      rating: 4.5,
      price: '₹22,000',
      duration: '6-7 days',
      highlights: ['Spiritual Sites', 'Trekking', 'Wildlife'],
      description: 'Spiritual journey through Himalayan foothills with pristine nature.'
    },
    {
      id: 6,
      name: 'Tamil Nadu',
      image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400&h=300&fit=crop',
      rating: 4.4,
      price: '₹16,000',
      duration: '5-6 days',
      highlights: ['Temples', 'Culture', 'Cuisine'],
      description: 'Rich cultural heritage with ancient temples and delicious South Indian cuisine.'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      <div className="pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Discover Amazing
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Destinations</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore India's most beautiful destinations and start planning your perfect getaway
            </p>
          </div>

          {/* Search and Filters */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-12">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Destination</label>
                <input
                  type="text"
                  placeholder="Where do you want to go?"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Duration</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent">
                  <option>Any Duration</option>
                  <option>3-4 days</option>
                  <option>5-6 days</option>
                  <option>7+ days</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Budget Range</label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent">
                  <option>Any Budget</option>
                  <option>₹10,000 - ₹20,000</option>
                  <option>₹20,000 - ₹30,000</option>
                  <option>₹30,000+</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">&nbsp;</label>
                <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                  Search
                </button>
              </div>
            </div>
          </div>

          {/* Destinations Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {destinations.map((destination) => (
              <div
                key={destination.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative">
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1 flex items-center space-x-1">
                    <Star className="text-yellow-400 fill-current" size={16} />
                    <span className="text-sm font-medium">{destination.rating}</span>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-bold text-gray-900">{destination.name}</h3>
                    <span className="text-lg font-bold text-travel-orange-600">{destination.price}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-600 mb-3">
                    <Calendar size={16} className="mr-2" />
                    <span className="text-sm">{destination.duration}</span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4">{destination.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {destination.highlights.map((highlight, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-gradient-to-r from-travel-orange-100 to-travel-purple-100 text-travel-purple-700 text-xs rounded-full"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                    Plan This Trip
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Destinations;
