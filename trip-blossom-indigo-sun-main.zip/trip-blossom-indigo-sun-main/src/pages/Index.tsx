
import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, Hotel, BusIcon, ChefHat, ArrowDown } from 'lucide-react';
import Navigation from '../components/Navigation';

const Index = () => {
  const features = [
    {
      icon: MapPin,
      title: 'Destination Planning',
      description: 'Discover amazing destinations and plan your perfect itinerary',
      link: '/destinations',
      gradient: 'from-travel-orange-400 to-travel-orange-600'
    },
    {
      icon: Calendar,
      title: 'Budget Planning',
      description: 'Plan your expenses in Indian Rupees with smart budgeting tools',
      link: '/budget',
      gradient: 'from-travel-purple-400 to-travel-purple-600'
    },
    {
      icon: Hotel,
      title: 'Hotels & Stays',
      description: 'Find the perfect accommodation for your journey',
      link: '/hotels',
      gradient: 'from-travel-orange-500 to-travel-purple-500'
    },
    {
      icon: BusIcon,
      title: 'Transport',
      description: 'Book flights, trains, and local transport with ease',
      link: '/transport',
      gradient: 'from-travel-purple-400 to-travel-orange-400'
    },
    {
      icon: ChefHat,
      title: 'Restaurants',
      description: 'Discover local cuisine and book amazing dining experiences',
      link: '/restaurants',
      gradient: 'from-travel-orange-600 to-travel-purple-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Plan Your
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Dream Trip</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              From destinations to budgets, hotels to restaurants - plan every aspect of your journey with our comprehensive travel planning platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/destinations"
                className="px-8 py-4 bg-gradient-to-r from-travel-orange-500 to-travel-orange-600 text-white rounded-xl font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200"
              >
                Start Planning
              </Link>
              <Link
                to="/budget"
                className="px-8 py-4 border-2 border-travel-purple-300 text-travel-purple-700 rounded-xl font-semibold hover:bg-travel-purple-50 hover:scale-105 transition-all duration-200"
              >
                Budget Calculator
              </Link>
            </div>
          </div>
          
          <div className="mt-16 animate-bounce">
            <ArrowDown className="mx-auto text-travel-orange-400" size={32} />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Everything You Need</h2>
            <p className="text-xl text-gray-600">All your travel planning tools in one place</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Link
                  key={index}
                  to={feature.link}
                  className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
                  style={{
                    animationDelay: `${index * 0.1}s`
                  }}
                >
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="text-white" size={28} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  <div className="mt-4 text-travel-orange-600 font-medium group-hover:text-travel-purple-600 transition-colors duration-200">
                    Explore →
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-travel-orange-500 to-travel-purple-600">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl font-bold mb-4">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 text-orange-100">
            Join thousands of travelers who trust TravelPlan for their adventures
          </p>
          <Link
            to="/destinations"
            className="inline-flex items-center px-8 py-4 bg-white text-travel-purple-700 rounded-xl font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200"
          >
            Plan Your Trip Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;
