
import React, { useState } from 'react';
import { Hotel, MapPin, Star, Calendar } from 'lucide-react';
import Navigation from '../components/Navigation';

const Hotels = () => {
  const [filters, setFilters] = useState({
    location: '',
    checkIn: '',
    checkOut: '',
    guests: 2,
    priceRange: 'all',
    rating: 'all'
  });

  const hotels = [
    {
      id: 1,
      name: 'The Grand Palace Hotel',
      location: 'Goa',
      image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop',
      rating: 4.8,
      price: 3500,
      originalPrice: 4200,
      amenities: ['Pool', 'Spa', 'Gym', 'Restaurant'],
      description: 'Luxury beachfront resort with stunning ocean views'
    },
    {
      id: 2,
      name: 'Mountain View Resort',
      location: 'Himachal Pradesh',
      image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=300&fit=crop',
      rating: 4.6,
      price: 2800,
      originalPrice: 3200,
      amenities: ['Mountain View', 'Fireplace', 'Restaurant', 'Parking'],
      description: 'Cozy mountain retreat perfect for nature lovers'
    },
    {
      id: 3,
      name: 'Heritage Palace',
      location: 'Rajasthan',
      image: 'https://images.unsplash.com/photo-1578774296838-c0aafdbeff75?w=400&h=300&fit=crop',
      rating: 4.9,
      price: 5200,
      originalPrice: 6000,
      amenities: ['Pool', 'Spa', 'Cultural Shows', 'Royal Dining'],
      description: 'Royal palace converted into luxury heritage hotel'
    },
    {
      id: 4,
      name: 'Backwater Villa',
      location: 'Kerala',
      image: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&h=300&fit=crop',
      rating: 4.7,
      price: 4100,
      originalPrice: 4800,
      amenities: ['Backwater View', 'Ayurveda', 'Boat Rides', 'Organic Food'],
      description: 'Serene villa overlooking Kerala backwaters'
    },
    {
      id: 5,
      name: 'City Center Hotel',
      location: 'Mumbai',
      image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&h=300&fit=crop',
      rating: 4.4,
      price: 3200,
      originalPrice: 3800,
      amenities: ['Business Center', 'Gym', 'Restaurant', 'WiFi'],
      description: 'Modern business hotel in the heart of the city'
    },
    {
      id: 6,
      name: 'Beach Resort Paradise',
      location: 'Tamil Nadu',
      image: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop',
      rating: 4.5,
      price: 2900,
      originalPrice: 3400,
      amenities: ['Beach Access', 'Water Sports', 'Pool', 'Restaurant'],
      description: 'Tropical paradise with direct beach access'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      <div className="pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Find Perfect
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Hotels</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover comfortable stays that fit your budget and preferences
            </p>
          </div>

          {/* Search and Filters */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-12">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <input
                  type="text"
                  placeholder="Where are you going?"
                  value={filters.location}
                  onChange={(e) => setFilters({...filters, location: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Check-in</label>
                <input
                  type="date"
                  value={filters.checkIn}
                  onChange={(e) => setFilters({...filters, checkIn: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Check-out</label>
                <input
                  type="date"
                  value={filters.checkOut}
                  onChange={(e) => setFilters({...filters, checkOut: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Guests</label>
                <select
                  value={filters.guests}
                  onChange={(e) => setFilters({...filters, guests: parseInt(e.target.value)})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                >
                  <option value={1}>1 Guest</option>
                  <option value={2}>2 Guests</option>
                  <option value={3}>3 Guests</option>
                  <option value={4}>4+ Guests</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">&nbsp;</label>
                <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                  Search Hotels
                </button>
              </div>
            </div>
            
            {/* Additional Filters */}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                  <select
                    value={filters.priceRange}
                    onChange={(e) => setFilters({...filters, priceRange: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                  >
                    <option value="all">All Prices</option>
                    <option value="budget">₹1,000 - ₹3,000</option>
                    <option value="mid">₹3,000 - ₹5,000</option>
                    <option value="luxury">₹5,000+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Star Rating</label>
                  <select
                    value={filters.rating}
                    onChange={(e) => setFilters({...filters, rating: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                  >
                    <option value="all">All Ratings</option>
                    <option value="5">5 Stars</option>
                    <option value="4">4+ Stars</option>
                    <option value="3">3+ Stars</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent">
                    <option>Price: Low to High</option>
                    <option>Price: High to Low</option>
                    <option>Rating: High to Low</option>
                    <option>Most Popular</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Hotels Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {hotels.map((hotel) => (
              <div
                key={hotel.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative">
                  <img
                    src={hotel.image}
                    alt={hotel.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1 flex items-center space-x-1">
                    <Star className="text-yellow-400 fill-current" size={16} />
                    <span className="text-sm font-medium">{hotel.rating}</span>
                  </div>
                  <div className="absolute top-4 left-4 bg-travel-orange-500 text-white px-3 py-1 rounded-lg text-sm font-medium">
                    {Math.round(((hotel.originalPrice - hotel.price) / hotel.originalPrice) * 100)}% OFF
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{hotel.name}</h3>
                  </div>
                  
                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin size={16} className="mr-2" />
                    <span className="text-sm">{hotel.location}</span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4">{hotel.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {hotel.amenities.map((amenity, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-gradient-to-r from-travel-orange-100 to-travel-purple-100 text-travel-purple-700 text-xs rounded-full"
                      >
                        {amenity}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-2xl font-bold text-travel-orange-600">₹{hotel.price}</span>
                      <span className="text-sm text-gray-500 line-through ml-2">₹{hotel.originalPrice}</span>
                      <div className="text-sm text-gray-500">per night</div>
                    </div>
                  </div>
                  
                  <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                    Book Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hotels;
