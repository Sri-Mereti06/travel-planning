
import React, { useState } from 'react';
import { BusIcon, MapPin, Calendar, Clock } from 'lucide-react';
import Navigation from '../components/Navigation';

const Transport = () => {
  const [activeTab, setActiveTab] = useState('flights');
  const [searchData, setSearchData] = useState({
    from: '',
    to: '',
    departure: '',
    return: '',
    passengers: 1
  });

  const transportOptions = {
    flights: [
      {
        id: 1,
        airline: 'IndiGo',
        from: 'Mumbai (BOM)',
        to: 'Goa (GOI)',
        departure: '10:30 AM',
        arrival: '11:45 AM',
        duration: '1h 15m',
        price: 4500,
        type: 'Non-stop'
      },
      {
        id: 2,
        airline: 'Air India',
        from: 'Delhi (DEL)',
        to: 'Jaipur (JAI)',
        departure: '2:15 PM',
        arrival: '3:30 PM',
        duration: '1h 15m',
        price: 3800,
        type: 'Non-stop'
      },
      {
        id: 3,
        airline: 'SpiceJet',
        from: 'Bangalore (BLR)',
        to: 'Chennai (MAA)',
        departure: '6:45 PM',
        arrival: '7:30 PM',
        duration: '45m',
        price: 3200,
        type: 'Non-stop'
      }
    ],
    trains: [
      {
        id: 1,
        name: 'Rajdhani Express',
        from: 'New Delhi',
        to: 'Mumbai Central',
        departure: '4:00 PM',
        arrival: '8:35 AM',
        duration: '16h 35m',
        price: 2800,
        class: '3AC'
      },
      {
        id: 2,
        name: 'Shatabdi Express',
        from: 'New Delhi',
        to: 'Chandigarh',
        departure: '7:20 AM',
        arrival: '10:50 AM',
        duration: '3h 30m',
        price: 1200,
        class: 'CC'
      },
      {
        id: 3,
        name: 'Konkan Railway',
        from: 'Mumbai CST',
        to: 'Margao',
        departure: '10:10 PM',
        arrival: '8:00 AM',
        duration: '9h 50m',
        price: 1800,
        class: '2AC'
      }
    ],
    buses: [
      {
        id: 1,
        operator: 'Volvo AC Sleeper',
        from: 'Bangalore',
        to: 'Mysore',
        departure: '10:30 PM',
        arrival: '4:00 AM',
        duration: '5h 30m',
        price: 800,
        type: 'AC Sleeper'
      },
      {
        id: 2,
        operator: 'Kerala State Transport',
        from: 'Kochi',
        to: 'Munnar',
        departure: '6:00 AM',
        arrival: '10:30 AM',
        duration: '4h 30m',
        price: 350,
        type: 'AC Seater'
      },
      {
        id: 3,
        operator: 'RSRTC Volvo',
        from: 'Jaipur',
        to: 'Udaipur',
        departure: '11:00 PM',
        arrival: '6:30 AM',
        duration: '7h 30m',
        price: 1200,
        type: 'AC Sleeper'
      }
    ]
  };

  const tabs = [
    { id: 'flights', label: 'Flights', icon: '✈️' },
    { id: 'trains', label: 'Trains', icon: '🚄' },
    { id: 'buses', label: 'Buses', icon: '🚌' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      <div className="pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Book Your
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Transport</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Compare and book flights, trains, and buses for your journey
            </p>
          </div>

          {/* Transport Type Tabs */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex space-x-1 bg-gray-100 rounded-xl p-1 mb-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <span className="text-lg">{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Search Form */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">From</label>
                <input
                  type="text"
                  placeholder="Departure city"
                  value={searchData.from}
                  onChange={(e) => setSearchData({...searchData, from: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
                <input
                  type="text"
                  placeholder="Destination city"
                  value={searchData.to}
                  onChange={(e) => setSearchData({...searchData, to: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Departure</label>
                <input
                  type="date"
                  value={searchData.departure}
                  onChange={(e) => setSearchData({...searchData, departure: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Passengers</label>
                <select
                  value={searchData.passengers}
                  onChange={(e) => setSearchData({...searchData, passengers: parseInt(e.target.value)})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                >
                  <option value={1}>1 Passenger</option>
                  <option value={2}>2 Passengers</option>
                  <option value={3}>3 Passengers</option>
                  <option value={4}>4+ Passengers</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">&nbsp;</label>
                <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                  Search
                </button>
              </div>
            </div>
          </div>

          {/* Transport Results */}
          <div className="space-y-6 mb-16">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">
                Available {tabs.find(tab => tab.id === activeTab)?.label}
              </h2>
              <div className="flex space-x-4">
                <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent">
                  <option>Sort by Price</option>
                  <option>Sort by Duration</option>
                  <option>Sort by Departure</option>
                </select>
              </div>
            </div>

            {transportOptions[activeTab].map((option) => (
              <div
                key={option.id}
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300"
              >
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">
                      {option.airline || option.name || option.operator}
                    </h3>
                    <div className="text-sm text-gray-600">
                      {option.type || option.class}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-gray-900">{option.departure}</div>
                      <div className="text-sm text-gray-600">{option.from}</div>
                    </div>
                    <div className="flex-1 relative">
                      <div className="border-t-2 border-dashed border-gray-300"></div>
                      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white px-2">
                        <BusIcon className="text-travel-orange-500" size={20} />
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-gray-900">{option.arrival}</div>
                      <div className="text-sm text-gray-600">{option.to}</div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center text-gray-600 mb-1">
                      <Clock size={16} className="mr-1" />
                      <span className="text-sm">{option.duration}</span>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-2xl font-bold text-travel-orange-600 mb-2">
                      ₹{option.price}
                    </div>
                    <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-2 rounded-lg font-semibold hover:shadow-lg transition-all duration-200">
                      Book Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Booking Options */}
          <div className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 rounded-2xl p-8 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">Need Help with Booking?</h2>
            <p className="text-lg mb-6 text-orange-100">
              Our travel experts are here to help you find the best transport options
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-6 py-3 bg-white text-travel-purple-700 rounded-lg font-semibold hover:shadow-lg transition-all duration-200">
                Call Expert
              </button>
              <button className="px-6 py-3 border-2 border-white text-white rounded-lg font-semibold hover:bg-white hover:text-travel-purple-700 transition-all duration-200">
                Live Chat
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Transport;
