import React, { useState } from 'react';
import { ChefHat, MapPin, Star, Clock } from 'lucide-react';
import Navigation from '../components/Navigation';

const Restaurants = () => {
  const [filters, setFilters] = useState({
    location: '',
    cuisine: 'all',
    priceRange: 'all',
    rating: 'all'
  });

  const restaurants = [
    {
      id: 1,
      name: 'Thalassa',
      location: 'Goa',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop',
      rating: 4.8,
      cuisine: 'Greek',
      priceRange: '₹₹₹',
      timing: '12:00 PM - 12:00 AM',
      specialties: ['Seafood', 'Mediterranean', 'Beach Dining'],
      description: 'Beachfront Greek restaurant with stunning sunset views'
    },
    {
      id: 2,
      name: 'Karavalli',
      location: 'Bangalore',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400&h=300&fit=crop',
      rating: 4.7,
      cuisine: 'South Indian',
      priceRange: '₹₹₹',
      timing: '7:00 PM - 11:30 PM',
      specialties: ['Coastal Cuisine', 'Traditional', 'Fine Dining'],
      description: 'Authentic coastal cuisine in elegant traditional setting'
    },
    {
      id: 3,
      name: 'Dum Pukht',
      location: 'Delhi',
      image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop',
      rating: 4.9,
      cuisine: 'Mughlai',
      priceRange: '₹₹₹₹',
      timing: '7:00 PM - 11:45 PM',
      specialties: ['Royal Cuisine', 'Slow Cooked', 'Luxury Dining'],
      description: 'Royal Mughlai cuisine with slow-cooking techniques'
    },
    {
      id: 4,
      name: 'Saravana Bhavan',
      location: 'Chennai',
      image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400&h=300&fit=crop',
      rating: 4.5,
      cuisine: 'South Indian',
      priceRange: '₹',
      timing: '6:00 AM - 11:00 PM',
      specialties: ['Vegetarian', 'Traditional', 'Filter Coffee'],
      description: 'Authentic vegetarian South Indian meals and tiffin'
    },
    {
      id: 5,
      name: 'Chokhi Dhani',
      location: 'Jaipur',
      image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop',
      rating: 4.6,
      cuisine: 'Rajasthani',
      priceRange: '₹₹',
      timing: '5:00 PM - 11:00 PM',
      specialties: ['Village Theme', 'Cultural Shows', 'Thali'],
      description: 'Village-themed restaurant with cultural entertainment'
    },
    {
      id: 6,
      name: 'Brittos',
      location: 'Goa',
      image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=300&fit=crop',
      rating: 4.4,
      cuisine: 'Continental',
      priceRange: '₹₹',
      timing: '8:00 AM - 1:00 AM',
      specialties: ['Beach Shack', 'Fresh Seafood', 'Goan Cuisine'],
      description: 'Famous beach shack serving fresh seafood and Goan delicacies'
    }
  ];

  const cuisineTypes = ['All Cuisines', 'North Indian', 'South Indian', 'Chinese', 'Continental', 'Mughlai', 'Rajasthani', 'Greek'];
  const priceRanges = ['All Prices', '₹ (Under ₹500)', '₹₹ (₹500-1000)', '₹₹₹ (₹1000-2000)', '₹₹₹₹ (₹2000+)'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-travel-orange-50 via-white to-travel-purple-50">
      <Navigation />
      
      <div className="pt-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Discover Amazing
              <span className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 bg-clip-text text-transparent"> Restaurants</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Find the best dining experiences and local cuisines for your journey
            </p>
          </div>

          {/* Search and Filters */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-12">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <input
                  type="text"
                  placeholder="Search by city"
                  value={filters.location}
                  onChange={(e) => setFilters({...filters, location: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cuisine Type</label>
                <select
                  value={filters.cuisine}
                  onChange={(e) => setFilters({...filters, cuisine: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                >
                  {cuisineTypes.map((cuisine) => (
                    <option key={cuisine} value={cuisine.toLowerCase().replace(' ', '-')}>
                      {cuisine}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <select
                  value={filters.priceRange}
                  onChange={(e) => setFilters({...filters, priceRange: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-travel-orange-500 focus:border-transparent"
                >
                  {priceRanges.map((range) => (
                    <option key={range} value={range.toLowerCase().replace(' ', '-')}>
                      {range}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">&nbsp;</label>
                <button className="w-full bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                  Find Restaurants
                </button>
              </div>
            </div>

            {/* Quick Filters */}
            <div className="flex flex-wrap gap-3">
              <span className="text-sm font-medium text-gray-700">Quick Filters:</span>
              {['Top Rated', 'Near Me', 'Open Now', 'Vegetarian', 'Fine Dining', 'Budget Friendly'].map((filter) => (
                <button
                  key={filter}
                  className="px-4 py-2 bg-gradient-to-r from-travel-orange-100 to-travel-purple-100 text-travel-purple-700 rounded-full text-sm font-medium hover:shadow-md transition-all duration-200"
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Restaurants Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {restaurants.map((restaurant) => (
              <div
                key={restaurant.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative">
                  <img
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1 flex items-center space-x-1">
                    <Star className="text-yellow-400 fill-current" size={16} />
                    <span className="text-sm font-medium">{restaurant.rating}</span>
                  </div>
                  <div className="absolute top-4 left-4 bg-travel-orange-500 text-white px-3 py-1 rounded-lg text-sm font-medium">
                    {restaurant.cuisine}
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{restaurant.name}</h3>
                    <span className="text-lg font-bold text-travel-orange-600">{restaurant.priceRange}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin size={16} className="mr-2" />
                    <span className="text-sm">{restaurant.location}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-600 mb-3">
                    <Clock size={16} className="mr-2" />
                    <span className="text-sm">{restaurant.timing}</span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-4">{restaurant.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {restaurant.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-gradient-to-r from-travel-orange-100 to-travel-purple-100 text-travel-purple-700 text-xs rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex space-x-3">
                    <button className="flex-1 bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                      Book Table
                    </button>
                    <button className="px-4 py-3 border-2 border-travel-orange-300 text-travel-orange-600 rounded-xl font-semibold hover:bg-travel-orange-50 transition-all duration-200">
                      Menu
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Featured Cuisines */}
          <div className="bg-gradient-to-r from-travel-orange-500 to-travel-purple-600 rounded-2xl p-8 text-white">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Explore Local Cuisines</h2>
              <p className="text-lg text-orange-100">
                Discover authentic flavors from different regions of India
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { name: 'Punjabi', emoji: '🍛' },
                { name: 'South Indian', emoji: '🥥' },
                { name: 'Bengali', emoji: '🐟' },
                { name: 'Rajasthani', emoji: '🌶️' },
                { name: 'Gujarati', emoji: '🥗' },
                { name: 'Goan', emoji: '🦐' },
                { name: 'Kashmiri', emoji: '🥘' },
                { name: 'Street Food', emoji: '🌮' }
              ].map((cuisine) => (
                <div
                  key={cuisine.name}
                  className="bg-white/20 backdrop-blur-sm rounded-xl p-4 text-center hover:bg-white/30 transition-all duration-200 cursor-pointer"
                >
                  <div className="text-3xl mb-2">{cuisine.emoji}</div>
                  <div className="font-semibold">{cuisine.name}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Restaurants;
